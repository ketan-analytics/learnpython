POEM CREDIT

"Summer Rain" by Amy Lowell
https://www.poets.org/poetsorg/poem/summer-rain
